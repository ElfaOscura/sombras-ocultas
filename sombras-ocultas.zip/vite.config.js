import { defineConfig } from 'vite';
import tailwindcss from '@tailwindcss/vite';
import { globSync } from 'glob';
import { readFileSync } from 'node:fs';
import { resolve, basename } from 'node:path';

/**
 * Parciales HTML: <!--@include partials/nav.html-->
 * Se reemplazan por el contenido del archivo (en dev y en build).
 * Más adelante cada parcial se convierte en un header.php / footer.php.
 */
const incluirParciales = () => ({
  name: 'incluir-parciales',
  transformIndexHtml: {
    order: 'pre',
    handler(html) {
      return html.replace(/<!--@include\s+(.+?)\s*-->/g, (_, ruta) =>
        readFileSync(resolve(__dirname, 'src', ruta.trim()), 'utf-8'),
      );
    },
  },
});

// Cada .html en la raíz es una página (index.html, guia-estilos.html, ...)
const paginas = Object.fromEntries(
  globSync('*.html', { cwd: __dirname }).map((f) => [basename(f, '.html'), resolve(__dirname, f)]),
);

export default defineConfig({
  // El sitio vive en naidiart.com/sombras-ocultas/
  base: '/sombras-ocultas/',
  plugins: [tailwindcss(), incluirParciales()],
  build: {
    rollupOptions: { input: paginas },
  },
});
